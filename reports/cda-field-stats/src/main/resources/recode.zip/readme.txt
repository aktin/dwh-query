Das Programm Recode liest eine CSV-Datei (�21-Datensatz) ein und codiert die Patienten-ID und Fall-ID mit einer Einweg-Hashfunktion. Die gleiche Hash-Funktion wird auch im Projekt AKTIN verwendet, so dass das Tool eine anonyme Zusammenf�hrung von AKTIN-Daten und �21-Daten erm�glicht.


Voraussetzungen:
Es muss eine aktuelle Java 8 (JRE) Version installiert sein.


Aufruf:
recode[.bat] <InputFile> <OutputFile> [<PatID-Column> <EncounterID-Column> [<PatID-Root> <EncounterID-Root>]]


Beispiel-Aufruf:
recode fall.csv out.csv Patientennummer KH-internes-Kennzeichen 1.2.276.0.76.4.8 1.2.276.0.76.3.87686
Die Datei out.csv kann dann anhand der IDs zu den Beispiel-Daten der Datei dwh-export.csv gemappt werden (die Angaben zu Aufnahmedatum, Geburtsdatum passen in diesem Beispiel-Datensatz nicht zusammen).


Parameter:
InputFile: �21-Fall-CSV mit Spalten�berschriften
OutputFile: CSV-Datei, in der die Spalten <PatID-Column> und <EncounterID-Column> gehasht sind (alle anderen Spalten werden �bernommen)
PatID-Column: [optional] Spalten�berschrift der PatID-Spalte in der Eingabedatei, default: "Patientennummer"
EncounterID-Column : [optional] Spalten�berschrift der EncounterID-Spalte in der Eingabedatei, default: "KH-internes-Kennzeichen"
PatID-Root: [optional] Root-ID des Patientenkennzeichens in AKTIN (siehe Erl�uterung), default: leer (root in CSV enthalten)
EncounterID-Root: [optional] Root-ID des Fallkennzeichens in AKTIN (siehe Erl�uterung), default: leer (root in CSV enthalten)
(Hinweis: Falls Root-IDs angegeben werden, m�ssen auch die Spalten�berschriften explizit angegeben werden)


Erl�uterung zu den Root-IDs:
F�r den Import in das AKTIN-DWH werden HL7-CDA Dokumente verwendet. Die Patienten-ID und Fall/Episoden-ID sind im CDA jeweils in einer Form wie z.B. <id root="1.2.276.0.76.4.8" extension="8772567330"/> einzutragen.
M�glichkeit 1:
Normalerweise sollte die root statisch sein und die extension den KIS-IDs entsprechen. Die IDs in der CSV-Datei k�nnen dann so verwendet werden, wie sie intern f�r den �21-Datensatz vorliegen. Zus�tzlich m�ssen dem recode-Programm die entsprechenden Root-IDs f�r die Hash-Berechnung mit �bergeben werden. In diesem Fall ist keine Vorverarbeitung der �21-Datei notwendig.
M�glichkeit 2:
Wenn dem Recode-Programm keine Root-IDs �bergeben werden, m�ssen die Spalten in der CSV-Datei entsprechend vorbereitet werden. Es muss dann in jeder Daten-zeile der CSV-Datei bereits root und extension stehen in der Form
<root>/<extension> (getrennt mit '/'). Falls nicht alle Patienten bzw. F�lle in AKTIN die gleiche Root-ID verwenden, muss diese Variante gew�hlt werden die IDs entsprechend vorverarbeitet in der CSV-Datei zu hinterlegen.


WICHTIG:
Bitte stellen Sie sicher, dass die IDs, die in der Eingabe-CSV angegeben werden, genau identisch sind mit denen, die f�r den Import in das AKTIN-DWH verwendet werden. Ggf. ist eine Vorverarbeitung oder ein Mapping auf andere IDs notwendig. Ein Mapping mit den AKTIN-Daten kann nur funktionieren wenn im DWH und im �21-Datensatz die gleichen IDs verwendet werden und somit die gleichen Hash-Werte entstehen.